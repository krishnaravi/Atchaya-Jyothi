<?php
/**
 * Panchang Calculation Logic
 */

if (!defined('ABSPATH')) {
    exit;
}

class Atchaya_Panchang_Calculator {

    public function get_panchang_data($date = '', $place = 'Vellore') {
        if (empty($date)) {
            $date = date('Y-m-d');
        }
        
        // Mocking the daily change logic
        // In a real implementation, this would call Swiss Ephemeris or an API
        $day_of_week = date('l', strtotime($date));
        
        return [
            'date' => $date,
            'place' => $place,
            'sunrise' => '06:15 AM',
            'sunset' => '06:20 PM',
            'tithi' => [
                'name' => 'Shukla Paksha Dashami',
                'tamil' => 'சுக்ல பட்ச தசமி',
                'end_time' => '10:45 PM'
            ],
            'nakshatra' => [
                'name' => 'Rohini',
                'tamil' => 'ரோகிணி',
                'end_time' => '02:30 PM'
            ],
            'yoga' => [
                'name' => 'Siddha',
                'tamil' => 'சித்த யோகம்',
                'end_time' => '05:00 PM'
            ],
            'karana' => [
                'name' => 'Taitila',
                'tamil' => 'சைதுளை',
                'end_time' => '11:00 AM'
            ],
            'rahu_kalam' => $this->get_rahu_kalam($day_of_week),
            'gulika_kalam' => '06:00 AM - 07:30 AM',
            'yamagandam' => '10:30 AM - 12:00 PM',
            'gowri_panchangam' => [
                'morning' => 'Amrutha',
                'evening' => 'Subha'
            ],
            'rasi_chart' => [
                '1' => 'Mesha',
                '2' => 'Rishaba (Moon)',
                '3' => 'Mithuna',
                '4' => 'Kataka',
                '5' => 'Simha',
                '6' => 'Kanya',
                '7' => 'Thula',
                '8' => 'Vrischika',
                '9' => 'Dhanus',
                '10' => 'Makara',
                '11' => 'Kumbha',
                '12' => 'Meena'
            ]
        ];
    }

    private function get_rahu_kalam($day) {
        $times = [
            'Monday' => '07:30 AM - 09:00 AM',
            'Tuesday' => '03:00 PM - 04:30 PM',
            'Wednesday' => '12:00 PM - 01:30 PM',
            'Thursday' => '01:30 PM - 03:00 PM',
            'Friday' => '10:30 AM - 12:00 PM',
            'Saturday' => '09:00 AM - 10:30 AM',
            'Sunday' => '04:30 PM - 06:00 PM'
        ];
        return $times[$day] ?? '07:30 AM - 09:00 AM';
    }
}
